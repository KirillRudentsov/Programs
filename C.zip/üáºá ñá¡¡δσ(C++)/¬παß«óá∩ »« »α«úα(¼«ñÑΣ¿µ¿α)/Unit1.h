//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Dialogs.hpp>
#include <cstring.h>
#include <string.h>
#include <vector.h>
//#include <list.h>
//#include <deque.h>
#include <Dialogs.hpp>
#include <Menus.hpp>
#include <algorithm>
#include <stdio.h>

  class sportsmen
{
	public:
	char name[30];
	char surname[30];
	char patronymic[30];
	int category;
	char type[30];


	// ����������� �� ��������� //

	sportsmen(){}

	// ����������� � ���������� //

	sportsmen(char *s,char *t,char *z,int q,char *w)
	{
	  strcpy(name,s);
	  strcpy(surname,t);
	  strcpy(patronymic,z);
	  category=q;
	  strcpy(type,w);

	}

	// ���������� ������������� ������� //

	friend bool operator < (const sportsmen&a,const sportsmen&b)
	{return a.category<b.category;}

	friend bool  Bysurname (const sportsmen&a,const sportsmen&b)
	{return a.surname<b.surname;}

	 friend bool  Bypatronymic (const sportsmen&a,const sportsmen&b)
	{return a.patronymic<b.patronymic;}

	friend bool Bytype(const sportsmen&a,const sportsmen&b)
	{return a.type<b.type;}

	friend bool operator == (const sportsmen&a,const sportsmen&b)
	{return a.category == b.category;}

	friend bool  Forname (sportsmen a,sportsmen b)
	{return strcmp(a.name,b.name)==0;}

	friend bool  Forsurname (const sportsmen&a,const sportsmen&b)
	{return a.surname == b.surname;}

	friend bool Forpatronymic (sportsmen &a,sportsmen &b)
	{return a.patronymic == b.patronymic;}

	friend bool Fortype (sportsmen &a,sportsmen &b)
	{return a.type == b.type;}

	friend bool Byname(const sportsmen&a,const sportsmen&b)
	{return a.name<b.name;}

	// ���������� //

	~sportsmen(){}
};
using namespace std;
extern vector <sportsmen> sport;
extern int Max,New;
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TEdit *Edit1;
	TEdit *Edit2;
	TEdit *Edit3;
	TEdit *Edit4;
	TEdit *Edit5;
	TLabel *Label1;
	TLabel *Label2;
	TLabel *Label3;
	TLabel *Label4;
	TLabel *Label5;
	TOpenDialog *OpenDialog1;
	TSaveDialog *SaveDialog1;
	TGroupBox *GroupBox1;
	TGroupBox *GroupBox2;
	TButton *Button4;
	TButton *Button5;
	TLabel *Label6;
	TEdit *Edit6;
	TButton *Button6;
	TButton *Button7;
	TEdit *Edit10;
	TButton *Button12;
	TButton *Button13;
	TMainMenu *MainMenu1;
	TMenuItem *FILE1;
	TMenuItem *Open1;
	TMenuItem *Save1;
	TMenuItem *Exit1;
	TMenuItem *Edit7;
	TMenuItem *Add2;
	TMenuItem *Erase1;
	void __fastcall Button4Click(TObject *Sender);
	void __fastcall Button5Click(TObject *Sender);
	void __fastcall Button13Click(TObject *Sender);
	void __fastcall Button12Click(TObject *Sender);
	void __fastcall Open1Click(TObject *Sender);
	void __fastcall Save1Click(TObject *Sender);
	void __fastcall Exit1Click(TObject *Sender);
	void __fastcall Add2Click(TObject *Sender);
	void __fastcall Button7Click(TObject *Sender);
	void __fastcall Button6Click(TObject *Sender);
	void __fastcall Erase1Click(TObject *Sender);
private:	// User declarations
public:
    void __fastcall ShowRecord();    	// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
