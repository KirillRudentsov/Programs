//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
#include <stdio.h>
TForm1 *Form1;
vector <sportsmen> sport;
int Max=0,New=0;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::ShowRecord()
{
Edit1->Text=sport[New].name;
Edit2->Text=sport[New].surname;
Edit3->Text=sport[New].patronymic;
Edit4->Text=IntToStr(sport[New].category);
Edit5->Text=sport[New].type;
Label6->Caption=IntToStr(New+1);
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
if(New<=0) return;
New--; ShowRecord();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button5Click(TObject *Sender)
{
if(New>=Max-1) return;
New++; ShowRecord();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button13Click(TObject *Sender)
{
sportsmen t;
vector <sportsmen>::iterator sports;
t.category=Edit10->Text.ToIntDef(0);
sports=find(sport.begin(),sport.end(),t);

	if(Edit10->Text.IsEmpty())
	{
	ShowMessage(" �� ������ �� ����� ��� ������ ");return;
	}
	if(sports==sport.end())
	 {
     ShowMessage(" ������ �� ����� ");return;
	 }
New=sports-sport.begin();
ShowRecord();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button12Click(TObject *Sender)
{
try {
sort(sport.begin(),sport.end());
New=0; ShowRecord();
if(Edit4->Text.IsEmpty()) throw Edit4->Text.t_str();
}
catch(...)
{
	MessageBox(NULL," �� ������ �� �����"," ������ ",MB_OK);
}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Open1Click(TObject *Sender)
{
OpenDialog1->Execute();
FILE *f=fopen(OpenDialog1->FileName.t_str(),"rb");
if(f==0)
		{
		ShowMessage(" �� �� ������� ��� ��������� ");return;
		}
for(int i=0;i<sport.max_size();i++)
		{
		sportsmen qeq;
		fread(&qeq,sizeof(sportsmen),1,f);
		if(feof(f)) break;
		sport.push_back(qeq);
		}
fclose(f);
Max=sport.size(); New=0; ShowRecord();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Save1Click(TObject *Sender)
{
SaveDialog1->Execute();
FILE *f=fopen(SaveDialog1->FileName.t_str(),"wb");
if(f)fwrite(&sport[0],sizeof(sportsmen),Max,f);
else {ShowMessage(" �� �� ������� ���� ");return;}
fclose(f);
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Exit1Click(TObject *Sender)
{
Form1->Close();
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Add2Click(TObject *Sender)
{
try
	{
	sport.push_back(sportsmen());
	strcpy(sport[Max].name,Edit1->Text.t_str());
	strcpy(sport[Max].surname,Edit2->Text.t_str());
	strcpy(sport[Max].patronymic,Edit3->Text.t_str());
	sport[Max].category=Edit4->Text.ToInt();
	strcpy(sport[Max].type,Edit5->Text.t_str());
	New=Max; Max++;
	Label6->Caption=IntToStr(Max);

		  if(Edit2->Text.IsEmpty()) throw Edit2->Text.t_str();

		  if(Edit1->NumbersOnly)
		  {
			  ShowMessage(" �� ������������ ���� ����� ");return;
		  }
	}
	catch(...)
	{
			ShowMessage(" ��������� ��� ����  !!!!!!!!!!! ");
	}
	 
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button7Click(TObject *Sender)
{
sportsmen w;
vector<sportsmen>::iterator heh;
strcpy(w.name,Edit6->Text.t_str());
heh=find_if(sport.begin(),sport.end(),bind2nd(ptr_fun(Forname),w));
if(heh==sport.end())
{
 ShowMessage(" �� ������ ������� ������ ������� ");return;
}
New=heh-sport.begin();
ShowRecord();
if(Edit6->Text.IsEmpty())
{
	ShowMessage(" �� ������ �� ����� ��� ������ !");
}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button6Click(TObject *Sender)
{
  try {
sort(sport.begin(),sport.end(),Byname);
New=0; ShowRecord();
if(Edit1->Text.IsEmpty()) throw Edit1->Text.t_str();
}
catch(...)
{
	MessageBox(NULL," �� ������ �� �����"," ������ ",MB_OK);
}
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Erase1Click(TObject *Sender)
{
	 if (sport.empty())
{
ShowMessage("������ �������!!!");
}
	 else {
				  sport.erase(sport.begin()+New);
				   }
			if (New==0)
			 {
				Max--;
				ShowRecord();
			 }
	   else
	 {
	   Max--;
	   New--;
	   ShowRecord();
	 }

}
//---------------------------------------------------------------------------

