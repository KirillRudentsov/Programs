#include "stdafx.h"
#include<conio.h>
#include<iostream>
#include<Windows.h>
using namespace std;

unsigned short Finish;

void Finished()
{
	system("cls");
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t     Victory! \n\n\n\n\n\n\n";
	cout<<"To close press Esc";
	Sleep(2500);
	exit(0);
}
void Lose()
{
	system("cls");
	cout<<"\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t     You lose!  \n\n\n\n\n\n\n\n\n";
	cout<<"To close press Esc";
	Sleep(2500);
	exit(0);
}

int _tmain(int argc, _TCHAR* argv[])
{
    HANDLE out_handle = GetStdHandle(STD_OUTPUT_HANDLE);    
    COORD maxWindow = GetLargestConsoleWindowSize(out_handle); // ������ ������ �������� ���������� ����������� ����
    SMALL_RECT srctWindow = { 0, 0, maxWindow.X - 1, maxWindow.Y - 1 };    
    SMALL_RECT minWindow = { 0, 0, 0, 0 };
    SetConsoleWindowInfo(out_handle, true, &minWindow);    
    SetConsoleScreenBufferSize(out_handle, maxWindow);
    SetConsoleWindowInfo(out_handle, true, &srctWindow);    

	int map[25][21] = { {1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,},
		                {1,0,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,},
                        {1,0,1,0,0,1,0,1,0,0,0,1,1,1,1,0,0,0,0,1,},
                        {1,0,1,1,0,1,0,1,0,1,0,0,0,0,1,0,1,1,0,1,},
                        {1,0,0,0,0,0,0,1,0,1,1,1,1,0,1,0,0,1,0,1,},
                        {1,1,1,1,1,1,0,1,0,1,0,0,1,0,1,1,0,1,0,1,},
                        {1,0,0,1,0,0,0,0,0,1,1,0,0,0,0,0,0,1,0,1,},
                        {1,0,1,1,0,1,1,1,1,1,0,0,1,0,1,1,1,1,0,1,},
                        {1,0,0,0,0,0,0,0,0,1,1,1,1,0,1,0,0,0,0,1,},
                        {1,1,1,1,1,1,0,1,1,1,0,0,0,0,1,0,1,1,1,1,},
                        {1,1,0,0,0,1,0,0,1,1,0,1,1,1,1,0,0,0,0,1,},
                        {1,0,0,1,0,0,0,0,0,1,0,0,0,0,1,1,1,1,0,1,},
                        {1,1,1,1,1,1,1,1,1,1,1,1,1,0,1,0,0,0,0,1,},
                        {1,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,1,1,1,},
                        {1,0,1,1,0,1,1,1,1,1,1,1,1,1,1,0,0,0,0,1,},
                        {1,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,1,1,0,1,},
                        {1,0,1,1,1,1,1,0,1,0,1,1,1,0,1,0,0,0,0,1,},
                        {1,0,1,0,0,0,1,0,1,0,0,0,1,1,1,1,1,1,1,1,},
                        {1,0,1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,1,},
                        {1,0,1,0,1,0,1,0,1,0,1,1,1,1,1,1,1,1,0,1,},
                        {1,0,1,0,1,0,1,0,1,0,0,0,0,0,0,0,0,0,0,1,},
                        {1,0,1,0,1,0,0,0,1,0,1,1,1,1,1,1,0,1,0,1,},
                        {1,0,1,0,1,1,1,1,1,0,0,0,1,0,1,0,0,1,0,1,},
                        {1,0,1,0,0,0,0,0,1,1,1,0,0,0,1,0,1,1,0,1,},
                        {1,3,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,} };

	int Free = 3, s1 = 1, s2 = 1;
	map[s1][s2] = 2;

	while( 0 == 0 )
	{
	system("cls");
	system(" color 3");
	for(int i = 0; i < 25; i++)
	{
		for(int j = 0; j < 20; j++)
		{
			if(map[i][j] == 1)
			{
				cout<< static_cast<char>(177);
				cout<< static_cast<char>(177);
			}
			if(map[i][j] == 2)
			{
				cout<< static_cast<char>(1);
				cout<< static_cast<char>(1);
			}
			if(map[i][j] == 0 || map[i][j] == 3)
			{
				cout<< "  ";
			}
		}
		cout<<endl;
	}
	Finish = _getch();
	Finish = _getch();
	if(Finish == 0)
    Finish = _getch();
	if(Finish == 72 || Finish == 150 || Finish == 230)    // �����
	{
		map[s1][s2] = 0;
		s1--;
		if(map[s1][s2] == 1)
		{
			Lose();
		}
		if(map[s1][s2] == Free)
		{
			Finished();
		}
		map[s1][s2] = 2;
	}
	if(Finish == 80 || Finish == 155 || Finish == 235)    // ����
	{
		map[s1][s2] = 0;
		s1++;
		if(map[s1][s2] == 1)
		{
			Lose();
		}
		if(map[s1][s2] == Free)
		{
			Finished();
		}
		map[s1][s2] = 2;
	}
	if(Finish == 77 || Finish == 130 || Finish == 262)    // ������
	{
		map[s1][s2] = 0;
		s2++;
		if(map[s1][s2] == 1)
		{
			Lose();
		}
		if(map[s1][s2] == Free)
		{
			Finished();
		}
		map[s1][s2] = 2;
	}
	if(Finish == 75 || Finish == 148 || Finish == 235)    // �����
	{
		map[s1][s2] = 0;
		s2--;
		if(map[s1][s2] == 1)
		{
			Lose();
		}
		if(map[s1][s2] == Free)
		{
			Finished();
		}
		map[s1][s2] = 2;
	}

	}
	_getch();
}

