﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;

namespace Client
{
    class Program
    {
        private static Socket _clientSocket = new Socket(AddressFamily.InterNetwork,SocketType.Stream,ProtocolType.Tcp);
        static void Main(string[] args)
        {
            Console.Title = "Client";
            LoopConnect();
            SendLoop();
            Console.ReadLine();
        }
        private static void SendLoop()
        {
            while (true)
            {
                Console.Write("Напиши мне что-нить: ");
                string req = Console.ReadLine();
                byte[] buffer = Encoding.ASCII.GetBytes(req);
                _clientSocket.Send(buffer);

                byte[] recivebuf = new byte[1024];
                int rec = _clientSocket.Receive(recivebuf);
                byte[] data = new byte[rec];
                Array.Copy(recivebuf,data,rec);
                Console.WriteLine("Received: "+ Encoding.ASCII.GetString(data));
            }
        }
        private static void LoopConnect()
        {
            int rer = 0;
            while (!_clientSocket.Connected)
            {
                try
                {
                    rer++;
                    string s = "192.168.1.116";
                    string sec = "195.26.31.43";
                   // IPAddress ip = IPAddress.Parse("10.0.2.15");
                   /// byte[] adress = ip.GetAddressBytes();
                   // string ipString = ip.ToString();
                    _clientSocket.Connect(new IPEndPoint(IPAddress.Loopback, 77));
                }
                catch (SocketException)
                {
                    Console.Clear();
                    Console.WriteLine("Connection attempt :" + rer.ToString());
                }
            }
            Console.Clear();
            Console.WriteLine("Ку Федя!!!!");
        }
        }
}
