﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SharpGL;
using SharpGL.Enumerations;
using SharpGL.SceneGraph.Assets;
using System.Windows;

using GL = SharpGL.OpenGL;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        OpenGL rer;
        float z = 0;
        static int count = 20000;
        int[] pointX = new int[count]; 
        int[] pointY = new int[count];
        int[] pointZ = new int[count];
 
        double[] ColorR = new double[count];
        double[] ColorG = new double[count];
        double[] ColorB = new double[count];


        public Form1()
        {
            InitializeComponent();
            rer = openGLControl1.OpenGL;
            Random r = new Random();
            for (int i = 0; i < count; i++)
            {
                pointX[i] = r.Next(-50, 50);
                pointY[i] = r.Next(-50, 50);
                pointZ[i] = r.Next(0,5000);

                ColorR[i] = r.NextDouble() / 2 + 0.5;
                ColorG[i] = r.NextDouble() / 2 + 0.5;
                ColorB[i] = r.NextDouble() / 2 + 0.5;
            }
           
        }
        
       
        //Свойство OpenGLDraw объекта openGLControl1, он как бы запускается много раз (Перерисовывает наши фигуры) 
        private void openGLControl1_OpenGLDraw(object sender, RenderEventArgs args)
        {  
            
            rer.Clear(OpenGL.GL_COLOR_BUFFER_BIT | OpenGL.GL_DEPTH_BUFFER_BIT);
            rer.LoadIdentity();   

            rer.LookAt(0,0,z += 1,0,0,1,0,1,0);

            rer.PointSize(2);
            

            rer.Begin(OpenGL.GL_POINTS);
            rer.Color(1f,1f,1f);
            for (int i = 0; i < count; i++)
            {
                rer.Color(ColorR[i],ColorG[i],ColorB[i]);
                rer.Vertex(pointX[i],pointY[i],pointZ[i]);
            }
            rer.End();
            rer.Flush();
            
        }  
            

        private void openGLControl1_OpenGLInitialized(object sender, EventArgs e)
        {
            
        }

        private void openGLControl1_Resize(object sender, EventArgs e)
        {

        }

        private void openGLControl1_Load(object sender, EventArgs e)
        {
             
        }
       
        private void openGLControl1_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void openGLControl1_KeyDown(object sender, KeyEventArgs e)
        {
            Close();
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
